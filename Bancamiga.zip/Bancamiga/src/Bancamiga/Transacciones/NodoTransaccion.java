/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bancamiga.Transacciones;

public class NodoTransaccion {

    Transaccion transaccion;
    NodoTransaccion siguiente;

    
    public NodoTransaccion() {
        transaccion = null;
        siguiente = null;
    }

    
    public NodoTransaccion(NodoTransaccion sig) {
        this.transaccion = null;
        this.siguiente = sig;
    }

    
    public NodoTransaccion(Transaccion tran) {
        this.transaccion = tran;
        this.siguiente = null;
    }

    
    public NodoTransaccion(Transaccion tran, NodoTransaccion sig) {
        this.transaccion = tran;
        this.siguiente = sig;
    }

    
    public Transaccion getTransaccion() {
        return this.transaccion;
    }

    public NodoTransaccion getSiguiente() {
        return this.siguiente;
    }

    
    public void setTransaccion(Transaccion tran) {
        this.transaccion = tran;
    }

    public void setSiguiente(NodoTransaccion sig) {
        this.siguiente = sig;
    }
}
