/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Bancamiga.Transacciones;

import Bancamiga.Transacciones.NodoTransaccion;
import Bancamiga.Clientes.Cliente;
import Bancamiga.Banco.TiempoActual;



public class PilaTransacciones {
    NodoTransaccion tope;
    int conteo;
    
    public PilaTransacciones(){
        tope = null;
        conteo = 0;
    }
    
    public boolean esVacia() {
        return tope == null;
    }
    
    public int getNumeroNodos(){
        return conteo;
    }
    
    public void vaciar(){
        tope = null;
        conteo = 0;
    }
    
    public NodoTransaccion vistazo(){
        return tope;
    }
    
    public void apilar(Transaccion transaccion) {
        NodoTransaccion nodo = new NodoTransaccion(transaccion);
        if (tope==null) {
            tope = nodo;
            conteo++;
        } else {
            NodoTransaccion nodoAux = tope;
            nodo.setSiguiente(nodoAux);
            tope = nodo;
            conteo++;
        }
    }
    
    public NodoTransaccion desapilar(){
        if(esVacia()){
            return null;
        } else {
            NodoTransaccion retornable = tope;
            tope = tope.getSiguiente();
            conteo--;
            return retornable;
        }
    }

}
