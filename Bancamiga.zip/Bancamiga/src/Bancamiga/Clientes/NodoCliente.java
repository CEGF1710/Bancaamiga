
package Bancamiga.Clientes;




public class NodoCliente {
    Cliente cliente;
    NodoCliente siguiente;
    boolean prioridad;
    
  
        
        public NodoCliente(){
            cliente = null;
            siguiente = null;
            prioridad = false;
        }
        
        
        public NodoCliente(NodoCliente sig, boolean prioridad){
            this.cliente = null;
            this.siguiente = sig;
            this.prioridad = prioridad;
        }
        
        
        public NodoCliente(Cliente cliente, boolean prioridad){
            this.cliente = cliente;
            this.siguiente = null;
            this.prioridad = prioridad;
        }
        
        
        public NodoCliente(Cliente cliente, NodoCliente sig, boolean prioridad){
            this.cliente = cliente;
            this.siguiente = sig;
            this.prioridad = prioridad;
        }
        
        
        public Cliente getCliente(){
            return this.cliente;
        }
        
        public NodoCliente getSiguiente(){
            return this.siguiente;
        }
        
        public boolean getPrioridad() {
            return this.prioridad;
        }
        
        
        public void setCliente(Cliente cli){
            this.cliente = cli;
        }
        
        public void setSiguiente(NodoCliente sig){
            this.siguiente = sig;
        }
        
        public void setPrioridad(boolean prioridad){
            this.prioridad = prioridad;
        }
}
