package Bancamiga.Solicitudes;


    public class NodoSolicitud{
        char solicitud;
        NodoSolicitud siguiente;
        
        
        
        public NodoSolicitud(){
            solicitud = '0';
            siguiente = null;
        }
        
        
        
        public NodoSolicitud(NodoSolicitud sig){
            this.solicitud = '0';
            this.siguiente = sig;
        }
        
       
        
        public NodoSolicitud(char sol){
            this.solicitud = sol;
            this.siguiente = null;
        }
        
        
        
        public NodoSolicitud(char sol, NodoSolicitud sig){
            this.solicitud = sol;
            this.siguiente = sig;
        }
        
        
        
        public char getSolicitud(){
            return this.solicitud;
        }
        
        public NodoSolicitud getSiguiente(){
            return this.siguiente;
        }
        
        
        
        public void setSolicitud(char sol){
            this.solicitud = sol;
        }
        
        public void setSiguiente(NodoSolicitud sig){
            this.siguiente = sig;
        }       
    }